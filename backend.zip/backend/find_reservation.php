<?php
	function reservation($username) {
		// link the website
		$link = mysql_connect('searchengine.web.engr.illinois.edu', 'searchengine_sliu105', 'ShuijingLiu123');
		if (!$link) {
			die('Could not connect: ' . mysql_error());
		}
		// choose database 
		mysql_select_db('searchengine_CSV_DB', $link);

		$sql = "SELECT * FROM reserved WHERE username = '$username'";
		$res = mysql_query($sql);

		print("<tr>
		<td align=\"center\"> ");
	

		if (mysql_num_rows($res)>0)
		{
			print("<p>You have " . mysql_num_rows($res) . " reservations:</p>");
			while($data=mysql_fetch_assoc($res)) {
			// print("<p><b> Gene: {$data['Gene_No']} </b>");
				print("<br><br>");

				print("<b><u>Hotel name:</u></b> {$data['reservedHotel']}<br/>");
				print("<b><u>Check in date:</u></b> {$data['check_in']}<br/>");
				print("<b><u>Check out date:</u></b> {$data['check_out']}<br/>");
				//print("<b><u>Gene Function:</u></b> {$data['Gene_Function']}<br/>");
				print("<br><br>");
			}

		}
		else {
			print("You have no reservations yet.");
		}

	}

?>