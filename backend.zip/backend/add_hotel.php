<?php
	// link the website
	$link = mysql_connect('searchengine.web.engr.illinois.edu', 'searchengine_sliu105', 'ShuijingLiu123');
	if (!$link) {
		die('Could not connect: ' . mysql_error());
	}
	//echo "hello world";
	// choose database 
	mysql_select_db('searchengine_CSV_DB', $link);


	$new_hotel = $_POST["input_name"];
	$address = $_POST["input_addr"];
	$price = $_POST["input_price"];
	$remain_num = $_POST["input_room"];

	if (strlen($new_hotel) > 55) {
		print("Hotel name is too long.<\br>");
	}
	else if (strlen($address) > 50) {
		print("Hotel address is too long.<\br>");
	}
	else if (strlen($remain_num) > 4) {
		print("Room remaining string is too long.<\br>");
	}

	else {
		$sql = "INSERT INTO `TABLE 4`(`hotel_name`, `address`, `price_per_room`, `room_remaining`) VALUES ('$new_hotel', '$address', '$price', '$remain_num')";
		$res=mysql_query($sql);
		if ($res < 1)
			print ("Add hotel " . $new_hotel . " " . $address . " failed.\r\n");
		else
			print("Add hotel " . $new_hotel . " " . $address . " succeeded.\r\n");
	}

	mysql_close($link);
?>