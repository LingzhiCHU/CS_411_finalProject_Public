<!-- <!DOCTYPE HTML>
<html>

   <body>
	<h1> Thank you, your reservation has been processed! </h1>
	 -->
	<?php
		# session_start();
		echo session_id();
		if(isset($_SESSION['userName'])) {
		  echo "Your session is running " . $_SESSION['userName'];
		}
		# echo $_SESSION["hotel_name"];
		echo "hello world";
	?>
	
<!--     <h3><a href="index.html" class="button">Back to home page</a> </h3>
    <h3><a href="login_index.html" class="button">Log in or Register</a> </h3> -->
 <!--   </body>
   
</html> -->