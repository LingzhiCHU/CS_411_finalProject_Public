<!-- <html> -->
<?php
	include("find_friend.php");
	include("find_reservation.php");

	// link the website
	$link = mysql_connect('searchengine.web.engr.illinois.edu', 'searchengine_sliu105', 'ShuijingLiu123');
	if (!$link) {
		die('Could not connect: ' . mysql_error());
	}
	// choose database 
	mysql_select_db('searchengine_CSV_DB', $link);

	# session_start();
	# print("hello");
	$email = $_POST["input_email"];
	$password_in = $_POST["input_password"];

	// sanity check
	if ($email == "") {
		print("Username is empty! \r\n");
		exit(1);
	}

	if ($password_in == "") {
		print("Password is empty! \r\n");
		exit(1);
	}

	$sql = "SELECT * FROM user WHERE emailAddr = '$email' AND password = '$password_in'";
	$result = mysql_query($sql);
	$count = mysql_num_rows($result);

	# print($count);	
	
	if($count == 1) {
		# print("hello");
		# session_register("email");
		$data=mysql_fetch_assoc($result);
		# print($data['username']);
		session_start();
		print(session_id());
		$_SESSION['login_user'] = $email;
		$user_check = $_SESSION['login_user'];
		print("Hello, ". $data['username']."!");
		
		reservation($data['username']);
		// echo '<input name = "$input_name" type="submit" value="Reserve now" />';
		echo '<a href="print_friends.php" class="button">Find travelmates</a>';
		 
		// echo '</form>';
		// find_friend($data['username']);
		
	}

	else {
		exit(1);
	}
?>
<!--   <head>
      <title>Welcome, "$result" </title>
   </head>
   
   <body>
      <h1>Welcome <?php  $login_session; ?></h1> 
      <h2> <a href="#"> My trips </h2>
      <h3> <a href="find_friend.php"> Find travelmates </h3>
      <h4><a href = "user_logout.php">Sign Out</a></h4>
   </body>
</html> -->