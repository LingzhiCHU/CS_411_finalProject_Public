<!-- <html>

	<body>
 -->
<?php
	include "user_login.php";
	session_start();
	print session_id();
	print $_SESSION['login_user'];
		// link the website
	$link = mysql_connect('searchengine.web.engr.illinois.edu', 'searchengine_sliu105', 'ShuijingLiu123');
	if (!$link) {
		die('Could not connect: ' . mysql_error());
	}
	// choose database 
	mysql_select_db('searchengine_CSV_DB', $link);


?>

<!-- 	</body>

</html> -->