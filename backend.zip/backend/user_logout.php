<?php
   session_destroy();
   print("You are signed out.")
?>