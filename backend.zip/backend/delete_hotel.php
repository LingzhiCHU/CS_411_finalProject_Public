<?php
	// link the website
	$link = mysql_connect('searchengine.web.engr.illinois.edu', 'searchengine_sliu105', 'ShuijingLiu123');
	if (!$link) {
		die('Could not connect: ' . mysql_error());
	}
	// choose database 
	mysql_select_db('searchengine_CSV_DB', $link);

	$delete_name = $_POST["input_name"];
	$delete_addr = $_POST["input_addr"];


	// delete function 
	if (strlen($delete_name) > 55) {
		print("Hotel name is too long.\r\n");
	}
	if (strlen($delete_addr) > 50) {
		print("Hotel address is too long.\r\n");
	}
	
	else {
		//print ("Hotel name = ".$delete_name.", hotel address = " . $delete_addr . "is deleted");
		$sql = "DELETE FROM `TABLE 4` 
			    WHERE hotel_name LIKE '%$delete_name%' AND address LIKE '%$delete_addr%'";
		$res = mysql_query($sql);
		if ($res < 1) {
			print("Deletion failed\r\n");
			print($res."result is returned.\r\n");
		}
		else
			print("Delete hotel " . $delete_name . " " . $delete_addr . " succeeded.\r\n");
		//print the result: 
	}
	mysql_close($link);
?>
