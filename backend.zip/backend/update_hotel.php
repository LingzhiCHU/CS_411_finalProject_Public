<?php
	// link the website
	$link = mysql_connect('searchengine.web.engr.illinois.edu', 'searchengine_sliu105', 'ShuijingLiu123');
	if (!$link) {
		die('Could not connect: ' . mysql_error());
	}
	// choose database 
	mysql_select_db('searchengine_CSV_DB', $link);

	$name = $_POST["input_name"];
	$addr = $_POST["input_addr"];
	$new_name = $_POST["new_input_name"];
	$new_addr = $_POST["new_input_addr"];
	$new_price = $_POST["new_input_price"];
	$new_room = $_POST["new_input_room"];

	if ($new_name == "" || $new_addr == "")
		print("Please enter valid name and address.\r\n");
	else{
	// echo "name = " . $name. "\r\n";
	// echo "address = " . $addr;
	// error check: if the hotel does not exist, do nothing
	$sql0 = "SELECT * FROM `TABLE 4` WHERE hotel_name LIKE '%$name%' AND address LIKE '%$addr%'";
	$res0 = mysql_query($sql0);

	if ($res0 < 1) {
		print("No hotel found. Please try again.");	
	}

	else {
	// might related to sql0 and improve efficiency???
		$sql = "UPDATE `TABLE 4` SET `hotel_name` = '$new_name', `address` = '$new_addr', 
		`price_per_room` = '$new_price', `room_remaining` = '$new_room'
		WHERE `hotel_name` LIKE '%$name%' AND `address` LIKE '%$addr%'";

		$res = mysql_query($sql);
		if ($res < 1) 
			print("Update failed. Please try again.");
		else 
			print("Update succeeded.");
	}
}
	mysql_close($link);
?>
